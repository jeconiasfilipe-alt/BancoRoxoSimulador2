BANCO ROXO SIMULADOR — projeto Android com compilação na nuvem

O app é um simulador independente, com saldo e transações fictícias. Não é o aplicativo Nubank, não se conecta a bancos e não movimenta dinheiro real.

GERAR APK USANDO APENAS O CELULAR (GitHub Actions)
1. Baixe e extraia este ZIP no celular.
2. No navegador, entre em https://github.com e crie uma conta ou entre na sua conta.
3. Crie um repositório novo chamado BancoRoxoSimulador. Para este teste, pode ser Public; não coloque informações pessoais no projeto.
4. Envie os arquivos e pastas deste projeto para a raiz do repositório, mantendo a estrutura, inclusive a pasta oculta .github/workflows e o arquivo build-apk.yml dentro dela. Se o site móvel não permitir enviar pastas, ative “Versão para computador” no menu do navegador.
5. Depois que os arquivos forem enviados para a branch main, abra a aba Actions do repositório.
6. Se aparecer um aviso para habilitar Actions, habilite-o. Abra “Build Banco Roxo Simulador APK” e acompanhe a execução até ficar verde (Success).
7. Abra a execução concluída, desça até Artifacts e toque em “BancoRoxoSimulador-APK” para baixar o ZIP do artefato.
8. Extraia esse ZIP no celular. Dentro estará app-debug.apk.
9. Toque em app-debug.apk e siga as instruções de instalação do Android. Se solicitado, permita instalar apps dessa origem nas configurações. Desative essa permissão depois, se preferir.

OBSERVAÇÕES
- O workflow usa GitHub Actions, Java 17 e Gradle 8.9 para compilar o APK.
- Se a compilação falhar, abra a execução em Actions e consulte o primeiro erro em vermelho.
- O APK é de depuração e não está assinado para distribuição pública.
- Não insira senhas bancárias nem dados financeiros reais.
